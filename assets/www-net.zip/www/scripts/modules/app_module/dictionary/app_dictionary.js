/**
 * Description : Script for holding application related data. Author : Rachna
 * Khokhar Date : 12-06-2013
 */

define({
	APP_ID : '21',
	LANG : 'English',
	CUST_TYPE : 'INDUS',
	IMEI : '000000000000000',
	DEVICE_LEVEL : 'Low',
	TRANS_ID : '0',
	MSISDN : '10364498',
	PNUM : '1234567890',
	
	LOGIN_REQ_ID : '25',
});